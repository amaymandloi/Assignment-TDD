package Com.TDD_Assignment.EvenOdd;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class EvenOddTests {
	@Test
	public void testOddNumbersExterminatorNormalList() {
	    //Given
	    EvenOdd oddNumbersExterminator = new EvenOdd();
	    ArrayList<Integer> normalList = new ArrayList<Integer>();
	    normalList.add(1);
	    normalList.add(2);
	    normalList.add(3);
	    normalList.add(4);
	    normalList.add(5);
	    normalList.add(6);
}
}